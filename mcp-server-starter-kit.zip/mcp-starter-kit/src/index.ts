import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import dotenv from 'dotenv';
import { registerTools } from './tools.js';
import { SecurityContext } from './auth.js';

dotenv.config();

const SERVER_NAME = process.env.SERVER_NAME || 'starter-mcp-server';
const SERVER_VERSION = process.env.SERVER_VERSION || '1.0.0';

// Default security context (can be populated via env or client tokens)
const securityContext: SecurityContext = {
  userId: 'local-developer',
  role: (process.env.USER_ROLE as any) || 'admin',
  scopes: ['inventory.read', 'orders.read', 'orders.write']
};

async function main() {
  // 1. Initialize MCP Server instance
  const server = new McpServer({
    name: SERVER_NAME,
    version: SERVER_VERSION
  });

  // 2. Register custom tools
  registerTools(server, securityContext);

  // 3. Connect via Standard I/O (Stdio) Transport
  const transport = new StdioServerTransport();
  await server.connect(transport);

  // Note: All logs must be written to stderr to avoid corrupting stdio JSON-RPC messages
  console.error(`[INFO] ${SERVER_NAME} v${SERVER_VERSION} running on stdio transport.`);
}

main().catch((err) => {
  console.error('[FATAL] Failed to start MCP Server:', err);
  process.exit(1);
});
