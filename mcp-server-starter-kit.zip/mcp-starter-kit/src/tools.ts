import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { SecurityContext, enforceAuth } from './auth.js';

/**
 * In-memory sample dataset simulating a backend inventory & order database.
 * In a real application, replace this with calls to your database (PostgreSQL, MongoDB)
 * or external REST APIs (using fetch / axios).
 */
const sampleInventory = [
  { sku: 'ITEM-101', name: 'Standard Wireless Barcode Scanner', stock: 42, min_reorder_level: 15, unit_price: 85.0 },
  { sku: 'ITEM-102', name: 'Thermal Receipt Paper Roll (50 Pack)', stock: 8, min_reorder_level: 20, unit_price: 24.5 },
  { sku: 'ITEM-103', name: 'Industrial RFID Reader Terminal', stock: 5, min_reorder_level: 10, unit_price: 340.0 },
  { sku: 'ITEM-104', name: 'Packaging Bubble Wrap Roll (100m)', stock: 65, min_reorder_level: 30, unit_price: 18.0 }
];

const sampleOrders = [
  { id: 'ORD-5001', customer: 'Apex Logistics Ltd', status: 'pending', total: 425.0, date: '2026-09-28' },
  { id: 'ORD-5002', customer: 'BlueWave Distribution', status: 'delivered', total: 1240.0, date: '2026-09-29' }
];

/**
 * Registers all custom MCP tools with the server instance.
 */
export function registerTools(mcp: McpServer, securityContext: SecurityContext) {

  // ==========================================
  // READ TOOL 1: Get Inventory & Stock Levels
  // ==========================================
  mcp.tool(
    'get_inventory_levels',
    'Retrieve current warehouse inventory levels, with optional low-stock filtering.',
    {
      only_low_stock: z
        .boolean()
        .optional()
        .describe('If true, returns only items whose stock is below the minimum reorder threshold.')
    },
    async (args) => {
      enforceAuth(securityContext, 'inventory.read');

      let results = sampleInventory;
      if (args.only_low_stock) {
        results = sampleInventory.filter((item) => item.stock < item.min_reorder_level);
      }

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(
              {
                count: results.length,
                items: results
              },
              null,
              2
            )
          }
        ]
      };
    }
  );

  // ==========================================
  // READ TOOL 2: Search Orders
  // ==========================================
  mcp.tool(
    'search_orders',
    'Search customer orders by status or customer name.',
    {
      status: z
        .enum(['pending', 'processing', 'delivered', 'cancelled'])
        .optional()
        .describe('Filter orders by status.'),
      query: z
        .string()
        .optional()
        .describe('Search query matching customer name or order ID.')
    },
    async (args) => {
      enforceAuth(securityContext, 'orders.read');

      let results = sampleOrders;
      if (args.status) {
        results = results.filter((order) => order.status === args.status);
      }
      if (args.query) {
        const q = args.query.toLowerCase();
        results = results.filter(
          (order) => order.id.toLowerCase().includes(q) || order.customer.toLowerCase().includes(q)
        );
      }

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(
              {
                matched_orders: results.length,
                orders: results
              },
              null,
              2
            )
          }
        ]
      };
    }
  );

  // ==========================================
  // WRITE TOOL 3: Create Restock Task / Order
  // ==========================================
  mcp.tool(
    'create_restock_order',
    'Create a new purchase/restock order for warehouse items. Requires orders.write permission.',
    {
      supplier_name: z.string().describe('Name of the supplier or vendor.'),
      notes: z.string().optional().describe('Special instructions or reference notes.'),
      items: z
        .array(
          z.object({
            sku: z.string().describe('Item SKU code'),
            quantity: z.number().int().positive().describe('Quantity to order')
          })
        )
        .min(1)
        .describe('List of SKUs and quantities to order.')
    },
    async (args) => {
      // Guardrail: write actions require elevated permission
      enforceAuth(securityContext, 'orders.write');

      const newOrderId = `RESTOCK-${Date.now().toString().slice(-4)}`;
      const newOrder = {
        id: newOrderId,
        supplier: args.supplier_name,
        items: args.items,
        notes: args.notes || 'Automated restock via MCP Agent',
        status: 'draft',
        created_at: new Date().toISOString()
      };

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(
              {
                success: true,
                message: 'Restock order successfully drafted.',
                order: newOrder
              },
              null,
              2
            )
          }
        ]
      };
    }
  );
}
