/**
 * Security & Authorization Middleware
 *
 * Use this module to enforce fine-grained permissions before allowing an LLM
 * to execute sensitive queries or data mutations (create, update, delete).
 */

export interface SecurityContext {
  userId?: string;
  role: 'admin' | 'manager' | 'operator' | 'readonly';
  scopes: string[];
}

/**
 * Validates whether the active caller context has the required permission scope.
 */
export function authorizeTool(context: SecurityContext, requiredScope: string): boolean {
  if (context.role === 'admin') {
    return true;
  }
  return context.scopes.includes(requiredScope);
}

/**
 * Throws a standardized structured error if authorization fails.
 */
export function enforceAuth(context: SecurityContext, requiredScope: string): void {
  if (!authorizeTool(context, requiredScope)) {
    throw new Error(
      JSON.stringify({
        code: 'FORBIDDEN',
        message: `Action denied: caller lacks required '${requiredScope}' permission.`,
        requiredScope,
        callerRole: context.role
      })
    );
  }
}
